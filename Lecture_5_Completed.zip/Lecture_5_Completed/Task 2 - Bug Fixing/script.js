const loadButton = document.getElementById("loadButton");
const postsContainer = document.getElementById("postsContainer");
const statusText = document.getElementById("status");

// Corrected bug 1: getElementById uses a lowercase "d".
async function loadPosts() {
  // Corrected bug 2: use let because the value is updated below.
  let status = "Loading posts...";
  statusText.textContent = status;
  postsContainer.innerHTML = "";

  try {
    // Corrected bug 3: await fetch inside an async function.
    const response = await fetch("https://jsonplaceholder.typicode.com/posts?_limit=6");
    if (!response.ok) {
      throw new Error("The server could not load the posts.");
    }
    const data = await response.json();

    data.forEach((post) => {
      const card = document.createElement("article");
      card.className = "rounded-2xl bg-slate-900 border border-slate-700 p-5";

      const heading = document.createElement("h2");
      // Corrected bug 4: the API post object uses "title".
      heading.textContent = post.title.toUpperCase();
      // Corrected bug 5: JavaScript method is toUpperCase().
      heading.className = "font-bold text-cyan-300 mb-3";

      const paragraph = document.createElement("p");
      paragraph.textContent = post.body;
      paragraph.className = "text-slate-300 leading-relaxed";

      card.appendChild(heading);
      card.appendChild(paragraph);
      postsContainer.appendChild(card);
    });

    status = `Loaded ${data.length} posts successfully.`;
    statusText.textContent = status;
  } catch (error) {
    statusText.textContent = `Error: ${error.message}`;
  }
}

// Corrected bug 6: addEventListener expects the event name "click".
loadButton.addEventListener("click", loadPosts);
