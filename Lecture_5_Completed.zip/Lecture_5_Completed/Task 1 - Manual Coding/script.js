const skillForm = document.getElementById("skillForm");
const skillInput = document.getElementById("skillInput");
const skillList = document.getElementById("skillList");
const skillCount = document.getElementById("skillCount");
const clearButton = document.getElementById("clearButton");
const emptyMessage = document.getElementById("emptyMessage");

let count = 0;

function updateCount() {
  count = skillList.children.length;
  skillCount.textContent = count;
  emptyMessage.classList.toggle("hidden", count > 0);
}

skillForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const skillText = skillInput.value.trim();
  if (skillText === "") {
    skillInput.focus();
    return;
  }

  const listItem = document.createElement("li");
  listItem.className = "flex items-center justify-between gap-3 rounded-xl bg-slate-800 border border-slate-700 px-4 py-3";

  const text = document.createElement("span");
  text.textContent = skillText;
  text.className = "break-words";

  const deleteButton = document.createElement("button");
  deleteButton.type = "button";
  deleteButton.textContent = "Delete";
  deleteButton.className = "shrink-0 rounded-lg bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 px-3 py-2 text-sm";
  deleteButton.setAttribute("aria-label", `Delete ${skillText}`);

  deleteButton.addEventListener("click", () => {
    listItem.remove();
    updateCount();
  });

  listItem.appendChild(text);
  listItem.appendChild(deleteButton);
  skillList.appendChild(listItem);

  skillInput.value = "";
  skillInput.focus();
  updateCount();
});

clearButton.addEventListener("click", () => {
  skillList.innerHTML = "";
  updateCount();
});

updateCount();
