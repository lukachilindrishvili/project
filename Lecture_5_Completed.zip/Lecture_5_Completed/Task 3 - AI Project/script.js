// Questions are stored as an array of objects.
const questions = [
  {
    question: "Which planet is known as the Red Planet?",
    answers: ["Venus", "Mars", "Jupiter", "Mercury"],
    correct: "Mars"
  },
  {
    question: "What is the name of the star at the center of our solar system?",
    answers: ["Sirius", "Polaris", "The Sun", "Vega"],
    correct: "The Sun"
  },
  {
    question: "Which planet has the most visible rings?",
    answers: ["Saturn", "Earth", "Neptune", "Mars"],
    correct: "Saturn"
  },
  {
    question: "What do astronauts wear in space to stay protected?",
    answers: ["Raincoat", "Space suit", "Swimwear", "Lab coat"],
    correct: "Space suit"
  },
  {
    question: "What is the name of the galaxy that contains our solar system?",
    answers: ["Andromeda", "Whirlpool", "Milky Way", "Sombrero"],
    correct: "Milky Way"
  }
];

// DOM elements are selected so JavaScript can update the page.
const questionNumber = document.getElementById("questionNumber");
const scoreText = document.getElementById("score");
const progress = document.getElementById("progress");
const questionText = document.getElementById("question");
const answersContainer = document.getElementById("answers");
const feedback = document.getElementById("feedback");
const nextButton = document.getElementById("nextButton");
const restartButton = document.getElementById("restartButton");

let currentQuestion = 0;
let score = 0;
let answered = false;

// Displays the current question and creates its answer buttons.
function showQuestion() {
  answered = false;
  const item = questions[currentQuestion];

  questionNumber.textContent = `Question ${currentQuestion + 1} of ${questions.length}`;
  scoreText.textContent = score;
  progress.style.width = `${((currentQuestion + 1) / questions.length) * 100}%`;
  questionText.textContent = item.question;
  feedback.textContent = "";
  answersContainer.innerHTML = "";
  nextButton.classList.add("hidden");

  item.answers.forEach((answer) => {
    const button = document.createElement("button");
    button.textContent = answer;
    button.className = "w-full text-left rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 px-4 py-4 transition";
    button.addEventListener("click", () => chooseAnswer(answer, button));
    answersContainer.appendChild(button);
  });
}

// Checks the selected answer and updates the score.
function chooseAnswer(answer, selectedButton) {
  if (answered) return;
  answered = true;

  const correctAnswer = questions[currentQuestion].correct;
  if (answer === correctAnswer) {
    score++;
    feedback.textContent = "Correct! Great job.";
    feedback.className = "min-h-7 mt-5 text-sm text-emerald-300";
    selectedButton.classList.add("border-emerald-400");
  } else {
    feedback.textContent = `Not quite. The correct answer is ${correctAnswer}.`;
    feedback.className = "min-h-7 mt-5 text-sm text-amber-300";
    selectedButton.classList.add("border-amber-400");
  }

  scoreText.textContent = score;
  Array.from(answersContainer.children).forEach((button) => {
    button.disabled = true;
    button.classList.add("opacity-60", "cursor-not-allowed");
  });

  if (currentQuestion === questions.length - 1) {
    nextButton.textContent = "See my result";
  } else {
    nextButton.textContent = "Next question";
  }
  nextButton.classList.remove("hidden");
}

// Moves to the next question or displays the final result.
function goToNextQuestion() {
  currentQuestion++;
  if (currentQuestion < questions.length) {
    showQuestion();
  } else {
    showResult();
  }
}

function showResult() {
  questionNumber.textContent = "Quiz complete";
  questionText.textContent = `You scored ${score} out of ${questions.length}!`;
  answersContainer.innerHTML = "";
  feedback.textContent = score === questions.length
    ? "Perfect score! Excellent work."
    : "Good effort! Review the questions and try again.";
  feedback.className = "min-h-7 mt-5 text-sm text-violet-300";
  progress.style.width = "100%";
  nextButton.classList.add("hidden");
  restartButton.classList.remove("hidden");
}

function restartQuiz() {
  currentQuestion = 0;
  score = 0;
  restartButton.classList.add("hidden");
  nextButton.textContent = "Next question";
  showQuestion();
}

nextButton.addEventListener("click", goToNextQuestion);
restartButton.addEventListener("click", restartQuiz);

// Start the quiz when the page loads.
showQuestion();
