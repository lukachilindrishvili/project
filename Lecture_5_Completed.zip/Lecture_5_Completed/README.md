# Lecture 5 – Completed Homework

This project contains all three tasks from the Lecture 5 assignment.

## How to use
1. Extract this folder.
2. Open `Task 1 - Manual Coding/index.html` in your browser and test adding, deleting, and clearing skills.
3. Open `Task 2 - Bug Fixing/index.html` in your browser and click **Load posts**. The JavaScript contains the six corrected concepts from the assignment.
4. Open `Task 3 - AI Project/index.html` in your browser and use the mini quiz.
5. Read `Task 3 - AI Project/submission_template.txt` and complete the personal reflection fields honestly.

No build tools or installation are required. Task 3 is a self-contained DOM-based quiz, so it works without an API key or internet connection.
